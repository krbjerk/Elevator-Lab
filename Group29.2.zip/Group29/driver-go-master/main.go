package main

import (
	"Driver-go/elevio"
	"fmt"
	"time"
)

type ElevatorBehavior int

var FloorTimer int

const (
	EB_idle ElevatorBehavior = iota
	EB_DoorOpen
	EB_Moving
)

type elevator struct {
	floor           int
	dirn            elevio.MotorDirection
	request         [][]int
	MadeRequestList []int
	behavior        ElevatorBehavior
}

func TakeRequest(EL elevator) {
	for i := range EL.request {
		if EL.request[i][2] == 1 {
			if EL.floor > i {
				elevio.SetMotorDirection(elevio.MD_Down)
				EL.dirn = elevio.MD_Down
				return
			}
			if EL.floor < i {
				elevio.SetMotorDirection(elevio.MD_Up)
				EL.dirn = elevio.MD_Up
				return
			}
		}
	}
}

func MakeRequest(EL elevator) {
	for i := range EL.request {

	}
}

func main() {

	numFloors := 4
	FloorTimer = 1

	elevio.Init("localhost:15657", numFloors)

	var d elevio.MotorDirection = elevio.MD_Stop
	elevio.SetMotorDirection(d)

	EL1 := elevator{
		floor:           0,
		dirn:            0,
		request:         make([][]int, numFloors),
		MadeRequestList: make([]int, 0),
		behavior:        0,
	}

	for i := range EL1.request {
		EL1.request[i] = make([]int, 3)
	}

	EL1.request[0][0] = 1

	drv_buttons := make(chan elevio.ButtonEvent)
	drv_floors := make(chan int)
	drv_obstr := make(chan bool)
	drv_stop := make(chan bool)

	go elevio.PollButtons(drv_buttons)
	go elevio.PollFloorSensor(drv_floors)
	go elevio.PollObstructionSwitch(drv_obstr)
	go elevio.PollStopButton(drv_stop)

	for {
		select {
		case a := <-drv_buttons:
			fmt.Printf("%+v\n", a)
			EL1.request[a.Floor][a.Button] = 1
			elevio.SetButtonLamp(a.Button, a.Floor, true)
			TakeRequest(EL1)

		case a := <-drv_floors:
			fmt.Printf("%+v\n", a)
			EL1.floor = a
			if EL1.request[a][2] == 1 {
				EL1.request[a][2] = 0
				elevio.SetMotorDirection(elevio.MD_Stop)
				elevio.SetButtonLamp(2, a, false)
				time.Sleep(time.Duration(FloorTimer) * time.Second)
			}
			TakeRequest(EL1)

		case a := <-drv_obstr:
			fmt.Printf("%+v\n", a)
			if a {
				elevio.SetMotorDirection(elevio.MD_Stop)
			} else {
				elevio.SetMotorDirection(d)
			}

		case a := <-drv_stop:
			fmt.Printf("%+v\n", a)
			for f := 0; f < numFloors; f++ {
				for b := elevio.ButtonType(0); b < 3; b++ {
					elevio.SetButtonLamp(b, f, false)
				}
			}
		}
	}

}
