package main

import (
	"fmt"
	"math"
	"time"
)

type ElevatorBehavior int

var FloorTimer = 2
var numFloors = 4
var MasterPriority int

const (
	EB_idle ElevatorBehavior = iota
	EB_Moving
	EB_DoorOpen
)

type elevator struct {
	floor    int
	dirn     MotorDirection
	behavior ElevatorBehavior
	request  [][]int
}

func TakeRequest(EL elevator) {
	for i := range EL.request {
		if EL.request[i][2] == 1 {
			if EL.floor > i {
				SetMotorDirection(MD_Down)
				EL.dirn = MD_Down
				return
			}
			if EL.floor < i {
				SetMotorDirection(MD_Up)
				EL.dirn = MD_Up
				return
			}
		}
	}
}

func MakeRequest(ELS []elevator) [][]int {
	var EL_requests = make([][]int, 3)
	var Finished_EL_requests = make([][]int, 3)
	EL_requests = [][]int{{0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}}
	var Time_Between_floors = 5
	for i := range ELS {
		for j := range ELS {
			for ii := 0; ii < numFloors; ii++ {
				if ELS[j].request[ii][0] == 1 {
					EL_requests[i][ii*2] = int(math.Abs(float64(ELS[i].floor)-float64(ii)))*Time_Between_floors + 2*int(ELS[i].dirn)*-int(math.Pow(float64(int(ELS[i].floor)-int(ii)), 0)) + int(ELS[i].behavior)
				}
				if ELS[j].request[ii][1] == 1 {
					EL_requests[i][ii*2+1] = int(math.Abs(float64(ELS[i].floor)-float64(ii)))*Time_Between_floors - 2*int(ELS[i].dirn)*-int(math.Pow(float64(int(ELS[i].floor)-int(ii)), 0)) + int(ELS[i].behavior)
				}
			}
		}
	}
	fmt.Printf("Requests: %+v", EL_requests)
	var while_v = 0
	for while_v < 1 {
		var lowest = 100
		var index = 0
		var floor = 0
		for i := range EL_requests {
			for j := range EL_requests[i] {
				if EL_requests[i][j] < lowest && EL_requests[i][j] != 0 {
					lowest = EL_requests[i][j]
					index = i
					floor = j
				}
			}
		}
		if lowest == 100 {
			while_v = 1
		}
		if lowest != 100 {
			Finished_EL_requests[index] = append(Finished_EL_requests[index], floor)
			EL_requests[0][floor] = 0
			EL_requests[1][floor] = 0
			EL_requests[2][floor] = 0
			for i := range EL_requests[index] {
				if EL_requests[index][i] != 0 {
					EL_requests[index][i] = EL_requests[index][i] + 3
					if floor%2 == 0 {
						if i > floor {
							EL_requests[index][i] = EL_requests[index][i] - 5
						}
					}
					if floor%2 != 0 {
						if i < floor {
							EL_requests[index][i] = EL_requests[index][i] - 5
						}
					}
				}
			}
		}
	}
	return Finished_EL_requests
}

func main() {

	MasterPriority = 0

	EL1 := elevator{
		floor:    3,
		dirn:     MD_Up,
		behavior: 2,
		request:  make([][]int, numFloors),
	}

	for i := range EL1.request {
		EL1.request[i] = make([]int, 3)
	}
	EL1.request[2][1] = 1

	Init("localhost:15657", numFloors)

	var d MotorDirection = MD_Stop
	SetMotorDirection(d)

	drv_buttons := make(chan ButtonEvent)
	drv_floors := make(chan int)
	drv_obstr := make(chan bool)
	drv_stop := make(chan bool)
	Send := make(chan string)

	go PollButtons(drv_buttons)
	go PollFloorSensor(drv_floors)
	go PollObstructionSwitch(drv_obstr)
	go PollStopButton(drv_stop)
	go SendToMaster(Send, EL1)

	for {
		select {
		case a := <-Send:
			fmt.Printf("%+v\n", a)
		case a := <-drv_buttons:
			fmt.Printf("%+v\n", a)
			EL1.request[a.Floor][a.Button] = 1
			SetButtonLamp(a.Button, a.Floor, true)
			TakeRequest(EL1)

		case a := <-drv_floors:
			fmt.Printf("%+v\n", a)
			EL1.floor = a
			if EL1.request[a][2] == 1 {
				EL1.request[a][2] = 0
				SetMotorDirection(MD_Stop)
				SetButtonLamp(2, a, false)
				time.Sleep(time.Duration(FloorTimer) * time.Second)
			}
			TakeRequest(EL1)

		case a := <-drv_obstr:
			fmt.Printf("%+v\n", a)
			if a {
				SetMotorDirection(MD_Stop)
			} else {
				SetMotorDirection(d)
			}

		case a := <-drv_stop:
			fmt.Printf("%+v\n", a)
			for f := 0; f < numFloors; f++ {
				for b := ButtonType(0); b < 3; b++ {
					SetButtonLamp(b, f, false)
				}
			}
		}
	}

}
