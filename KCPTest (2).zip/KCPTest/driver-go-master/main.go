package main

import (
	"Driver-go/elevio"
	"fmt"
	"math"
	"time"
)

type ElevatorBehavior int

var FloorTimer = 2
var numFloors = 4

const (
	EB_idle ElevatorBehavior = iota
	EB_Moving
	EB_DoorOpen
)

type elevator struct {
	floor    int
	dirn     elevio.MotorDirection
	request  [][]int
	behavior ElevatorBehavior
}

func TakeRequest(EL elevator) {
	for i := range EL.request {
		if EL.request[i][2] == 1 {
			if EL.floor > i {
				elevio.SetMotorDirection(elevio.MD_Down)
				EL.dirn = elevio.MD_Down
				return
			}
			if EL.floor < i {
				elevio.SetMotorDirection(elevio.MD_Up)
				EL.dirn = elevio.MD_Up
				return
			}
		}
	}
}

func MakeRequest(ELS []elevator) [][]int {
	var EL_requests = make([][]int, 3)
	var Finished_EL_requests = make([][]int, 3)
	EL_requests = [][]int{{0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}}
	var Time_Between_floors = 5
	for i := range ELS {
		for j := range ELS {
			for ii := 0; ii < numFloors; ii++ {
				if ELS[j].request[ii][0] == 1 {
					EL_requests[i][ii*2] = int(math.Abs(float64(ELS[i].floor)-float64(ii)))*Time_Between_floors + 2*int(ELS[i].dirn)*-int(math.Pow(float64(int(ELS[i].floor)-int(ii)), 0)) + int(ELS[i].behavior)
				}
				if ELS[j].request[ii][1] == 1 {
					EL_requests[i][ii*2+1] = int(math.Abs(float64(ELS[i].floor)-float64(ii)))*Time_Between_floors - 2*int(ELS[i].dirn)*-int(math.Pow(float64(int(ELS[i].floor)-int(ii)), 0)) + int(ELS[i].behavior)
				}
			}
		}
	}
	fmt.Printf("Requests: %+v", EL_requests)
	var while_v = 0
	for while_v < 1 {
		var lowest = 100
		var index = 0
		var floor = 0
		for i := range EL_requests {
			for j := range EL_requests[i] {
				if EL_requests[i][j] < lowest && EL_requests[i][j] != 0 {
					lowest = EL_requests[i][j]
					index = i
					floor = j
				}
			}
		}
		if lowest == 100 {
			while_v = 1
		}
		if lowest != 100 {
			Finished_EL_requests[index] = append(Finished_EL_requests[index], floor)
			EL_requests[0][floor] = 0
			EL_requests[1][floor] = 0
			EL_requests[2][floor] = 0
			for i := range EL_requests[index] {
				if EL_requests[index][i] != 0 {
					EL_requests[index][i] = EL_requests[index][i] + 3
					if floor%2 == 0 {
						if i > floor {
							EL_requests[index][i] = EL_requests[index][i] - 5
						}
					}
					if floor%2 != 0 {
						if i < floor {
							EL_requests[index][i] = EL_requests[index][i] - 5
						}
					}
				}
			}
		}
	}
	return Finished_EL_requests
}

func main() {
	EL1 := elevator{
		floor:    0,
		dirn:     0,
		request:  make([][]int, numFloors),
		behavior: 0,
	}

	elevio.Init("localhost:15657", numFloors)

	var d elevio.MotorDirection = elevio.MD_Stop
	elevio.SetMotorDirection(d)

	drv_buttons := make(chan elevio.ButtonEvent)
	drv_floors := make(chan int)
	drv_obstr := make(chan bool)
	drv_stop := make(chan bool)

	go elevio.PollButtons(drv_buttons)
	go elevio.PollFloorSensor(drv_floors)
	go elevio.PollObstructionSwitch(drv_obstr)
	go elevio.PollStopButton(drv_stop)

	for {
		select {
		case a := <-drv_buttons:
			fmt.Printf("%+v\n", a)
			EL1.request[a.Floor][a.Button] = 1
			elevio.SetButtonLamp(a.Button, a.Floor, true)
			TakeRequest(EL1)

		case a := <-drv_floors:
			fmt.Printf("%+v\n", a)
			EL1.floor = a
			if EL1.request[a][2] == 1 {
				EL1.request[a][2] = 0
				elevio.SetMotorDirection(elevio.MD_Stop)
				elevio.SetButtonLamp(2, a, false)
				time.Sleep(time.Duration(FloorTimer) * time.Second)
			}
			TakeRequest(EL1)

		case a := <-drv_obstr:
			fmt.Printf("%+v\n", a)
			if a {
				elevio.SetMotorDirection(elevio.MD_Stop)
			} else {
				elevio.SetMotorDirection(d)
			}

		case a := <-drv_stop:
			fmt.Printf("%+v\n", a)
			for f := 0; f < numFloors; f++ {
				for b := elevio.ButtonType(0); b < 3; b++ {
					elevio.SetButtonLamp(b, f, false)
				}
			}
		}
	}

}
