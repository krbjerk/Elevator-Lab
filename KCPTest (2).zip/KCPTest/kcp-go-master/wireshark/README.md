## macOS
    - Copy kcp_dissector.lua to /Applications/Wireshark.app/Contents/PlugIns/wireshark
