package main

import (
	"fmt"
	"net"
	"os"
	"os/exec"
	"strconv"
	"syscall"
	"time"
)

// We define DETACHED_PROCESS and CREATE_NEW_PROCESS_GROUP ourselves, so we don't
// get "undefined: syscall.DETACHED_PROCESS" on modern Go versions.
const (
	DETACHED_PROCESS         = 0x00000008
	CREATE_NEW_PROCESS_GROUP = 0x00000200
)

// Configuration
const (
	UDP_PORT         = 3333
	TAKEOVER_TIMEOUT = 3

	// Primary increments count and sends heartbeat every heartbeatInterval seconds.
	HEARTBEAT_INTERVAL = 1
)

func spawnBackup() error {
	cmd := exec.Command(
		"cmd", "/C", "start",
		"powershell",
		"go", "run", "processPair.go", "backup",
	)

	// DETACH so the new console remains running if/when the old one exits.
	cmd.SysProcAttr = &syscall.SysProcAttr{
		CreationFlags: DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
	}

	err := cmd.Start()
	if err != nil {
		fmt.Printf("[ERROR] spawnBackup failed: %v\n", err)
	} else {
		fmt.Println("[Primary] Spawned a new backup in another console window.")
	}
	return err
}

// The primary increments a counter and sends heartbeats (the current count)
// to 127.0.0.1:UDPPort until it is killed.
func primaryLoop(startCount int64) {
	fmt.Printf("[Primary] Now running primary loop, starting at count = %d\n", startCount)

	// Prepare to send UDP heartbeats
	remoteAddr := net.UDPAddr{
		IP:   net.IPv4(127, 0, 0, 1),
		Port: UDP_PORT,
	}

	conn, err := net.DialUDP("udp", nil, &remoteAddr)
	if err != nil {
		fmt.Println("[Primary] DialUDP error:", err)
		return
	}
	defer conn.Close()

	count := startCount
	for {
		count++
		msg := strconv.FormatInt(count, 10)

		// Send to backup
		_, werr := conn.Write([]byte(msg))
		if werr != nil {
			fmt.Println("[Primary] Heartbeat write error:", werr)
		}

		// Show progress
		fmt.Printf("[Primary] count = %d\n", count)

		// Sleep for heartbeat interval
		time.Sleep(HEARTBEAT_INTERVAL * time.Second)
	}
}

// The backup listens for UDP heartbeats from the primary. If they stop for
// takeover timeout, the backup becomes the new primary.
func backupLoop() {
	fmt.Println("[Backup] Starting backup loop.")

	listenAddr := net.UDPAddr{
		IP:   net.IPv4(127, 0, 0, 1),
		Port: UDP_PORT,
	}
	conn, err := net.ListenUDP("udp", &listenAddr)
	if err != nil {
		fmt.Printf("[Backup] ListenUDP error: %v\n", err)
		return // We can’t proceed if we can’t bind
	}

	fmt.Printf("[Backup] Listening for heartbeats on UDP port %d\n", UDP_PORT)

	// We'll track the last time we got a heartbeat, plus the last count we saw
	lastHeartbeat := time.Now()
	var lastCount int64

	buffer := make([]byte, 1024)

	for {
		// Set a read deadline to detect if the primary goes silent
		deadline := time.Now().Add(time.Duration(TAKEOVER_TIMEOUT) * time.Second)
		conn.SetReadDeadline(deadline)

		n, _, err := conn.ReadFromUDP(buffer)
		if err != nil { // Some connection error.
			netErr, ok := err.(net.Error)
			if ok && netErr.Timeout() { // if things are ok and we have timeout in the connection.
				// No heartbeat within takeoverTimeout => assume primary died
				silenceDuration := time.Since(lastHeartbeat)
				if silenceDuration.Seconds() > TAKEOVER_TIMEOUT { // Timedout for long enough
					fmt.Printf("[Backup] No heartbeat from primary for %.2f sec; taking over.\n", silenceDuration.Seconds())

					// 1) Close our listening socket so we free UDPPort
					conn.Close()
					// 2) Become primary, continuing from the last count
					becomePrimary(lastCount)
					return // Quit
				}
				// If we still havent past the the time we set for loss of primary, continue listening
				// by skipping to next loop of the for loop.
				continue
			}
			// Non-timeout error.
			fmt.Println("[Backup] Read error (non-timeout):", err)

			conn.Close()
			becomePrimary(lastCount)
			return // Quit
		}

		// We got a heartbeat. Parse the count from text
		msg := string(buffer[:n])
		c, parseErr := strconv.ParseInt(msg, 10, 64)
		if parseErr != nil {
			// Ignore malformed packets
			fmt.Printf("[Backup] Malformed heartbeat: %s\n", msg)
			continue
		}

		// Update last known count and heartbeat
		lastCount = c
		lastHeartbeat = time.Now()
		// Debug if desired: fmt.Printf("[Backup] Got heartbeat, count = %d\n", c)
	}
}

// Called by the backup when it detects the old primary died. We spawn a new
// backup, then run the primary loop ourselves, continuing the count where
// the old primary left off.
func becomePrimary(lastCount int64) {
	fmt.Println("[Backup->Primary] Transitioning this backup into the new primary!")
	// Sleep a bit so Windows fully frees the UDP port.
	time.Sleep(1 * time.Second)

	fmt.Println("[Primary] Spawning our new backup process ...")
	err := spawnBackup()
	if err != nil {
		fmt.Println("[Primary] spawnBackup failed:", err)
		// We can continue, but we have no new backup…

		// If you wanted to keep retrying or handle the error differently, do so here.
	}

	// Now run the primary loop ourselves, continuing the count.
	primaryLoop(lastCount)
}

func main() {
	// If launched with "backup" arg, we are the backup.
	// The backup process will then run the backuploop function. The backup loop function
	// can use the three other function in the code; primary, spawn and become to create an infinite loop.
	if len(os.Args) > 1 && os.Args[1] == "backup" {
		backupLoop()
		return
	}

	// Otherwise, we are the original primary.
	// This functions spawns a new powershell process which will run the backupfunction as above us.
	fmt.Println("[Primary] Spawning initial backup process…")
	_ = spawnBackup()

	// This function will start and send the count to the backup. Doesnt do more than that.
	// Start counting from zero.
	primaryLoop(0)
}
